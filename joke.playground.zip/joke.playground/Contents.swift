import UIKit

var greeting = "Hello, playground"
var joke = "what do skeletans eat for dinner"
var answer = " air" 
